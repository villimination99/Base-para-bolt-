/* VILLUMINATION99 - Shopify Theme JS */

document.addEventListener('DOMContentLoaded', function() {
  // === SPLASH INTRO ===
  var splash = document.getElementById('splash-intro');
  var enterBtn = document.getElementById('splash-enter');

  if (splash) {
    // Check if already seen this session
    if (sessionStorage.getItem('v99_intro_seen')) {
      splash.style.display = 'none';
    } else {
      document.body.style.overflow = 'hidden';

      if (enterBtn) {
        enterBtn.addEventListener('click', function() {
          splash.classList.add('dismissed');
          document.body.style.overflow = '';
          sessionStorage.setItem('v99_intro_seen', '1');
          setTimeout(function() {
            splash.style.display = 'none';
          }, 900);
        });
      }
    }
  }
  // Navbar scroll effect
  var navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  }

  // Mobile menu toggle
  var mobileToggle = document.querySelector('.mobile-toggle');
  var mobileMenu = document.querySelector('.mobile-menu');
  var mobileMenuPanel = document.querySelector('.mobile-menu-panel');

  function closeMobileMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.remove('open');
    document.body.style.overflow = '';
    document.documentElement.style.overflow = '';
  }

  function openMobileMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.add('open');
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    if (mobileMenuPanel) mobileMenuPanel.scrollTop = 0;
  }

  if (mobileToggle && mobileMenu) {
    mobileToggle.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      if (mobileMenu.classList.contains('open')) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    });
  }

  // Close menu on overlay click or close button
  document.addEventListener('click', function(e) {
    if (mobileMenu && (e.target.classList.contains('mobile-menu-overlay') || e.target.closest('.mobile-menu-close'))) {
      closeMobileMenu();
    }
  });

  // Close menu on link click
  if (mobileMenu) {
    var menuLinks = mobileMenu.querySelectorAll('a');
    for (var i = 0; i < menuLinks.length; i++) {
      menuLinks[i].addEventListener('click', function() {
        closeMobileMenu();
      });
    }
  }

  // Smooth scroll for hash links
  var hashLinks = document.querySelectorAll('a[href*="#"]');
  for (var i = 0; i < hashLinks.length; i++) {
    hashLinks[i].addEventListener('click', function(e) {
      var href = this.getAttribute('href');
      var hash = href.indexOf('#') !== -1 ? href.substring(href.indexOf('#')) : null;
      if (hash && hash.length > 1) {
        var target = document.querySelector(hash);
        if (target) {
          e.preventDefault();
          if (mobileMenu) closeMobileMenu();
          target.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  }

  // Hero typing animation
  var heroTyped = document.getElementById('hero-typed');
  if (heroTyped) {
    var words = ['FUERZA', 'DISCIPLINA', 'PODER', 'GRANDEZA', 'VICTORIA'];
    var colors = ['#00e0ff', '#ff2ecb', '#ff6600', '#00e87b', '#ffd000'];
    var wordIndex = 0;
    var charIndex = 0;
    var isDeleting = false;
    var typeSpeed = 120;

    function typeEffect() {
      var currentWord = words[wordIndex];
      var currentColor = colors[wordIndex];

      if (isDeleting) {
        heroTyped.textContent = currentWord.substring(0, charIndex - 1);
        charIndex--;
        typeSpeed = 60;
      } else {
        heroTyped.textContent = currentWord.substring(0, charIndex + 1);
        charIndex++;
        typeSpeed = 120;
      }

      heroTyped.style.color = currentColor;
      heroTyped.style.textShadow = '0 0 10px ' + currentColor + ', 0 0 30px ' + currentColor + '80';

      if (!isDeleting && charIndex === currentWord.length) {
        typeSpeed = 2000;
        isDeleting = true;
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        wordIndex = (wordIndex + 1) % words.length;
        typeSpeed = 300;
      }

      setTimeout(typeEffect, typeSpeed);
    }

    setTimeout(typeEffect, 1500);
  }

  // Scroll to top
  var scrollTopBtn = document.querySelector('.scroll-top-btn');
  if (scrollTopBtn) {
    scrollTopBtn.addEventListener('click', function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Toast notification on add to cart
  function showToast(message) {
    var toast = document.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(function() {
      toast.classList.remove('show');
    }, 2500);
  }

  // Add to cart forms
  var cartForms = document.querySelectorAll('form[action="/cart/add"]');
  for (var i = 0; i < cartForms.length; i++) {
    cartForms[i].addEventListener('submit', function() {
      showToast('Producto agregado al carrito!');
    });
  }

  // === BILLING TOGGLE (Monthly / Annual) ===
  var billingToggle = document.getElementById('billing-toggle');
  var toggleMonthly = document.getElementById('toggle-monthly');
  var toggleAnnual = document.getElementById('toggle-annual');
  var isAnnual = false;

  function updatePricing() {
    var period = isAnnual ? 'annual' : 'monthly';
    var lang = document.documentElement.getAttribute('data-lang') || 'es';

    // Update toggle button styles
    if (isAnnual) {
      toggleMonthly.style.background = 'transparent';
      toggleMonthly.style.border = '1px solid transparent';
      toggleMonthly.style.color = '#6b7280';
      toggleAnnual.style.background = 'rgba(0,255,136,0.15)';
      toggleAnnual.style.border = '1px solid rgba(0,255,136,0.3)';
      toggleAnnual.style.color = '#00ff88';
    } else {
      toggleMonthly.style.background = 'rgba(0,255,136,0.15)';
      toggleMonthly.style.border = '1px solid rgba(0,255,136,0.3)';
      toggleMonthly.style.color = '#00ff88';
      toggleAnnual.style.background = 'transparent';
      toggleAnnual.style.border = '1px solid transparent';
      toggleAnnual.style.color = '#6b7280';
    }

    // Update prices
    var mains = document.querySelectorAll('.price-main');
    var cents = document.querySelectorAll('.price-cents');
    var periods = document.querySelectorAll('.price-period');
    var savings = document.querySelectorAll('.annual-savings');

    for (var i = 0; i < mains.length; i++) {
      mains[i].textContent = mains[i].getAttribute('data-' + period);
    }
    for (var i = 0; i < cents.length; i++) {
      cents[i].textContent = cents[i].getAttribute('data-' + period);
    }
    for (var i = 0; i < periods.length; i++) {
      periods[i].textContent = periods[i].getAttribute('data-' + lang + '-' + period);
    }
    for (var i = 0; i < savings.length; i++) {
      savings[i].style.display = isAnnual ? 'block' : 'none';
    }
  }

  if (toggleMonthly && toggleAnnual) {
    toggleMonthly.addEventListener('click', function() {
      isAnnual = false;
      updatePricing();
    });
    toggleAnnual.addEventListener('click', function() {
      isAnnual = true;
      updatePricing();
    });
  }

  // === LANGUAGE DETECTION (Browser/IP based) ===
  function detectLanguage() {
    var lang = navigator.language || navigator.userLanguage || 'es';
    lang = lang.substring(0, 2).toLowerCase();
    if (lang !== 'es' && lang !== 'en') lang = 'es';
    return lang;
  }

  function applyTranslations(lang) {
    document.documentElement.setAttribute('data-lang', lang);
    var elements = document.querySelectorAll('.i18n');
    for (var i = 0; i < elements.length; i++) {
      var el = elements[i];
      var text = el.getAttribute('data-' + lang);
      if (text) el.textContent = text;
    }
    // Update price periods for current billing state
    var periods = document.querySelectorAll('.price-period');
    var period = isAnnual ? 'annual' : 'monthly';
    for (var i = 0; i < periods.length; i++) {
      var periodText = periods[i].getAttribute('data-' + lang + '-' + period);
      if (periodText) periods[i].textContent = periodText;
    }
  }

  var detectedLang = detectLanguage();
  applyTranslations(detectedLang);
});
